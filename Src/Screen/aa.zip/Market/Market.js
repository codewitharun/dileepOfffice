import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const Market = () => {
    return (
        <View>
            <Text>Market</Text>
        </View>
    )
}

export default Market

const styles = StyleSheet.create({})