import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const Stacking = () => {
    return (
        <View>
            <Text>Stacking</Text>
        </View>
    )
}

export default Stacking

const styles = StyleSheet.create({})